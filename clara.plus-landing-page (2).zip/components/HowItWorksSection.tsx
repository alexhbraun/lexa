import React from 'react';

const Step: React.FC<{ icon: string; title: string; description: string; isLast?: boolean }> = ({ icon, title, description, isLast = false }) => (
    <div className="relative pl-16">
        {!isLast && <div className="absolute left-[18px] top-12 h-full w-0.5 bg-sky/30"></div>}
        <div className="absolute left-0 top-0 h-10 w-10 bg-coral text-white rounded-full flex items-center justify-center text-lg font-bold ring-8 ring-sand">
            {icon}
        </div>
        <h3 className="font-bold font-heading text-xl text-ink">{title}</h3>
        <p className="mt-2 text-ink/80">{description}</p>
    </div>
);


export const HowItWorksSection: React.FC = () => {
  return (
    <section id="how-it-works" className="py-20 bg-sand scroll-mt-20">
        <div className="container mx-auto px-6">
            <div className="text-center max-w-3xl mx-auto">
                <h2 className="text-3xl md:text-4xl font-bold font-heading text-ink">
                    Simples de começar. Mágico de usar.
                </h2>
            </div>

            <div className="mt-16 max-w-2xl mx-auto space-y-12">
                <Step 
                    icon="1" 
                    title="Paciente liga para sua clínica." 
                    description="Ele pode ligar a qualquer hora, para o seu número de telefone atual." 
                />
                 <Step 
                    icon="2" 
                    title="Clara conversa com o paciente." 
                    description="Com sua voz natural e empática, ela entende a necessidade: agendar, confirmar ou tirar uma dúvida." 
                />
                 <Step 
                    icon="3" 
                    title="A mágica acontece: tudo resolvido." 
                    description="A consulta é marcada na agenda, o paciente recebe a confirmação e sua equipe, um resumo completo." 
                />
                 <Step 
                    icon="4" 
                    title="Sua equipe focada no que importa." 
                    description="Zero interrupções. Apenas um fluxo de trabalho mais calmo e pacientes bem atendidos."
                    isLast={true}
                />
            </div>
        </div>
    </section>
  );
};
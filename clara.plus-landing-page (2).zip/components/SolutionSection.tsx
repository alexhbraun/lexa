import React from 'react';

const CheckIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-coral mr-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
    </svg>
);

export const SolutionSection: React.FC = () => {
  return (
    <section id="solution" className="py-20 bg-white scroll-mt-20">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold font-heading text-ink">
                A recepcionista AI que soa humana de verdade.
            </h2>
            <p className="mt-4 text-lg text-ink/80">
                Clara não é um robô de respostas prontas. É uma IA de voz treinada para ser calma, empática e profissional, representando o padrão de cuidado da sua clínica.
            </p>
        </div>

        <div className="mt-12 max-w-2xl mx-auto space-y-4">
            <div className="flex items-start p-5 bg-sand/50 rounded-xl">
                <CheckIcon />
                <p className="text-ink">Atende 24/7 com uma voz calma e profissional.</p>
            </div>
             <div className="flex items-start p-5 bg-sand/50 rounded-xl">
                <CheckIcon />
                <p className="text-ink">Agenda, reagenda e cancela consultas automaticamente.</p>
            </div>
             <div className="flex items-start p-5 bg-sand/50 rounded-xl">
                <CheckIcon />
                <p className="text-ink">Envia confirmações e lembretes por WhatsApp.</p>
            </div>
             <div className="flex items-start p-5 bg-sand/50 rounded-xl">
                <CheckIcon />
                <p className="text-ink">Integra-se perfeitamente à sua agenda atual.</p>
            </div>
            <div className="flex items-start p-5 bg-sand/50 rounded-xl">
                <CheckIcon />
                <p className="text-ink">Transcreve e resume cada chamada para sua equipe.</p>
            </div>
        </div>
      </div>
    </section>
  );
};
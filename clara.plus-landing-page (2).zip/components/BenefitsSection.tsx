import React from 'react';

const BenefitCard: React.FC<{ title: string; description: string; icon: React.ReactNode }> = ({ title, description, icon }) => (
    <div className="bg-white p-8 rounded-2xl border border-sand transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
        <div className="text-coral mb-5">{icon}</div>
        <h3 className="text-xl font-bold font-heading text-ink">{title}</h3>
        <p className="mt-2 text-ink/80">{description}</p>
    </div>
);

const LeafIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.362 5.214A8.252 8.252 0 0112 21 8.25 8.25 0 016.038 7.048 8.287 8.287 0 009 9.6a8.983 8.983 0 013.362-3.797A8.333 8.333 0 0112 2.25c1.153 0 2.243.3 3.224.865zM16.388 3.282A8.287 8.287 0 0012 2.25a8.287 8.287 0 00-4.388 1.032M19.656 9.6c0 2.623-1.8 4.907-4.362 5.198a8.333 8.333 0 01-4.114-1.603A8.333 8.333 0 0112 2.25c2.623 0 4.907 1.8 5.198 4.362a8.333 8.333 0 011.458 3z" />
    </svg>
);

const WandIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.53 16.122a3 3 0 00-3.48-2.14-3 3 0 00-3.48 2.141L2.34 21.84a2.25 2.25 0 002.134 2.959l.206-.052a2.25 2.25 0 002.324-2.043l.21-1.282zM16.53 8.122a3 3 0 00-3.48-2.14-3 3 0 00-3.48 2.141L6.34 14.84a2.25 2.25 0 002.134 2.959l.206-.052a2.25 2.25 0 002.324-2.043l.21-1.282z" />
    </svg>
);

const SmileIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.828 14.828a4.082 4.082 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);


export const BenefitsSection: React.FC = () => {
  return (
    <section id="benefits" className="py-20 bg-white scroll-mt-20">
        <div className="container mx-auto px-6">
            <div className="text-center max-w-3xl mx-auto">
                <h2 className="text-3xl md:text-4xl font-bold font-heading text-ink">
                    Mais que automação, uma revolução no cuidado.
                </h2>
            </div>
            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
                <BenefitCard 
                    icon={<LeafIcon />}
                    title="Equipe mais feliz e produtiva"
                    description="Livre sua recepção da sobrecarga de ligações. Menos estresse, mais foco no atendimento humanizado dentro da clínica."
                />
                <BenefitCard 
                    icon={<WandIcon />}
                    title="Percepção de modernidade"
                    description="Mostre que sua clínica está na vanguarda, oferecendo uma experiência tecnológica e eficiente desde o primeiro 'alô'."
                />
                <BenefitCard 
                    icon={<SmileIcon />}
                    title="Pacientes encantados"
                    description="Atendimento imediato, sem espera e com clareza. Uma experiência que fideliza e gera indicações."
                />
            </div>
             <div className="mt-16 text-center">
                <p className="text-xl md:text-2xl italic text-ink/70 max-w-3xl mx-auto">
                   “A primeira impressão do seu cuidado começa no telefone.”
                </p>
            </div>
        </div>
    </section>
  );
};
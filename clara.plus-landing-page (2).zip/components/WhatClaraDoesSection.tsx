
import React, { useState, Suspense, lazy } from 'react';
import { Modal } from './Modal';

const AudioDemoContent = lazy(() => import('./AudioDemoContent'));

const stepsData = [
  {
    number: '①',
    title: 'Atendimento Imediato e Agendamento Inteligente',
    description: 'A Clara atende 100% das ligações, 24h por dia. Ela identifica o motivo da chamada — seja um novo agendamento, dúvida sobre exames ou pedido de informação — e conduz a conversa com voz natural e empática. Quando o paciente deseja marcar uma consulta, a Clara acessa o calendário da clínica, agenda automaticamente e, se necessário, envia documentos ou formulários diretamente por WhatsApp durante a conversa.',
    cards: [
      { icon: '🗣️', title: 'Voz natural e empática', description: 'O paciente sente que está falando com uma pessoa real, não um robô.' },
      { icon: '🗓️', title: 'Agenda inteligente e integrada', description: 'Marca e confirma horários diretamente no sistema da clínica.' },
      { icon: '📄', title: 'Envia documentos durante a ligação', description: 'A Clara pode enviar guias, formulários ou instruções via WhatsApp, sem interromper a chamada.' },
    ]
  },
  {
    number: '②',
    title: 'Comunicação Proativa e Lembretes Inteligentes',
    description: 'Após marcar a consulta, a Clara envia lembretes automáticos por WhatsApp ou ligação de voz, conforme a preferência da clínica ou do paciente. Esses lembretes reduzem significativamente faltas e cancelamentos.',
    cards: [
      { icon: '💬', title: 'Lembretes por WhatsApp', description: 'Confirmações rápidas e discretas.' },
      { icon: '📞', title: 'Ligações automáticas', description: 'Um toque mais pessoal, ideal para consultas importantes.' },
    ],
    highlight: 'Resultado: Redução de até 30% nas faltas e remarcações.',
    cta: 'Ouça como a Clara faz isso na prática →'
  },
  {
    number: '③',
    title: 'Pós-consulta e Atendimento Contínuo',
    description: 'Ao final de cada ligação, a Clara gera um resumo automático do atendimento e envia para a equipe da clínica. Nada se perde — todas as interações ficam registradas, facilitando acompanhamento e auditoria.',
    cards: [
      { icon: '🧾', title: 'Resumo e notificação automática', description: 'O atendimento completo é registrado e enviado ao WhatsApp ou painel da clínica.' },
    ]
  }
];

const StepNumber: React.FC<{ number: string }> = ({ number }) => (
    <div className="h-12 w-12 flex-shrink-0 flex items-center justify-center bg-coral/10 border-2 border-coral rounded-full font-bold text-coral text-2xl shadow-[0_0_20px_rgba(255,110,91,0.4)]">
        {number}
    </div>
);

const FeatureCard: React.FC<{ icon: string; title: string; description: string }> = ({ icon, title, description }) => (
    <div className="card-gradient-border p-px rounded-2xl h-full transition-transform duration-300 hover:-translate-y-1">
        <div className="bg-card/70 backdrop-blur-lg h-full p-6 rounded-[15px] text-center flex flex-col">
            <div className="text-4xl mx-auto mb-4 h-12 w-12 flex items-center justify-center">{icon}</div>
            <h4 className="font-bold text-lg text-ink-1">{title}</h4>
            <p className="text-ink-2 mt-1 text-sm flex-grow">{description}</p>
        </div>
    </div>
);

interface WhatClaraDoesSectionProps {
    onNavigateToPrep: () => void;
}

export const WhatClaraDoesSection: React.FC<WhatClaraDoesSectionProps> = ({ onNavigateToPrep }) => {
    const [isAudioModalOpen, setIsAudioModalOpen] = useState(false);

    const handleBookFromAudioDemo = () => {
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({ event: 'demo_to_booking' });
        setIsAudioModalOpen(false);
        setTimeout(() => {
            onNavigateToPrep();
        }, 200);
    };

    const getGridColsClass = (count: number) => {
        switch (count) {
            case 1:
                return 'grid-cols-1 max-w-sm mx-auto';
            case 2:
                return 'grid-cols-1 sm:grid-cols-2';
            case 3:
                return 'grid-cols-1 md:grid-cols-3';
            default:
                return 'grid-cols-1 sm:grid-cols-2';
        }
    };


    return (
        <>
            <section 
              id="how-it-works" 
              className="scroll-mt-20 reveal relative py-24 md:py-20 sm:py-12"
              style={{ backgroundColor: '#18112D' }}
            >
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,110,91,0.1),transparent_60%)] -z-10"></div>
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-px bg-gradient-to-r from-transparent via-violet-acc to-transparent opacity-20"></div>

                <div className="container mx-auto px-6">
                    <div className="text-center max-w-3xl mx-auto">
                        <h2 className="text-3xl md:text-4xl font-bold section-title">
                            A jornada de atendimento completa com a Clara
                        </h2>
                        <p className="mt-4 text-lg text-ink-2">Do "Alô" ao pós-consulta, veja como automatizamos cada passo com empatia e precisão.</p>
                    </div>

                    <div className="relative mt-20 max-w-4xl mx-auto">
                        <div className="space-y-12 md:space-y-20">
                            {stepsData.map((step, index) => (
                                <div key={index} className="relative pl-20 reveal">
                                    {index < stepsData.length - 1 && (
                                      <div className="absolute left-[23px] top-12 h-full w-0.5 bg-coral/25" aria-hidden="true"></div>
                                    )}
                                    <div className="absolute left-0 top-0"><StepNumber number={step.number} /></div>
                                    <h3 className="text-2xl font-semibold text-ink-1 mb-3">{step.title}</h3>
                                    <p className="text-ink-2 mb-8">{step.description}</p>
                                    
                                    {step.highlight && (
                                        <p className="mb-4 text-white font-semibold bg-coral/10 px-4 py-2 rounded-lg inline-block">{step.highlight}</p>
                                    )}

                                    {step.cta && (
                                        <div className="my-6">
                                            <button onClick={() => setIsAudioModalOpen(true)} className="font-semibold text-white hover:text-ink-2 transition-colors group text-base">
                                                {step.cta}
                                            </button>
                                        </div>
                                    )}

                                    <div className={`mt-8 grid gap-6 ${getGridColsClass(step.cards.length)}`}>
                                        {step.cards.map((card, cardIndex) => (
                                            <FeatureCard key={cardIndex} {...card} />
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-coral to-violet-acc opacity-30"></div>
            </section>
            
            <Modal
                isOpen={isAudioModalOpen}
                onClose={() => setIsAudioModalOpen(false)}
                maxWidthClass="max-w-md"
                titleId="reminder-audio-title"
                descriptionId="reminder-audio-desc"
            >
                <Suspense fallback={<div className="h-[244px]" />}>
                    {isAudioModalOpen && <AudioDemoContent onBookDemo={handleBookFromAudioDemo} titleId="reminder-audio-title" descriptionId="reminder-audio-desc" />}
                </Suspense>
            </Modal>
        </>
    );
};

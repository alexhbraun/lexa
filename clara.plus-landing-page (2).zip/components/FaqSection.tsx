import React, { useState } from 'react';
import { FaqItem } from '../types';
import { HelpCircleIcon } from './Icons';

const faqData: FaqItem[] = [
  {
    question: "A Clara substitui minha recepcionista?",
    answer: "Pelo contrário. Clara é a melhor assistente que sua recepcionista poderia ter. Ela cuida do repetitivo para que sua equipe possa focar no atendimento presencial e estratégico."
  },
  {
    question: "Ela entende sotaques e variações de fala?",
    answer: "Sim. Nossa IA foi treinada exaustivamente com o português brasileiro, compreendendo uma vasta gama de sotaques e formas de falar para garantir uma comunicação natural."
  },
  {
    question: "Como os resumos das chamadas são enviados?",
    answer: "Imediatamente após cada chamada, um resumo claro e objetivo é enviado para o WhatsApp ou e-mail da sua equipe. Tudo documentado e de fácil acesso."
  },
  {
    question: "Os dados dos meus pacientes estão seguros?",
    answer: "Absolutamente. Levamos a LGPD a sério. Usamos criptografia de ponta e seguimos as melhores práticas de segurança para garantir a total confidencialidade dos dados."
  },
  {
    question: "Posso testar a Clara antes de contratar?",
    answer: "Sim! Oferecemos um teste gratuito, sem custos e sem pedir seu cartão. Queremos que você sinta o impacto da Clara na prática antes de qualquer compromisso."
  }
];

const FaqAccordionItem: React.FC<{ item: FaqItem; isOpen: boolean; onClick: () => void; index: number }> = ({ item, isOpen, onClick, index }) => {
    const buttonId = `faq-question-${index}`;
    const panelId = `faq-answer-${index}`;

    return (
        <div className="border-b border-border">
            <button 
                onClick={onClick} 
                className="w-full flex justify-between items-center text-left py-6"
                id={buttonId}
                aria-expanded={isOpen}
                aria-controls={panelId}
            >
                <span className="flex items-center text-lg font-medium text-ink-1">
                  <HelpCircleIcon className="w-6 h-6 text-coral mr-4" />
                  {item.question}
                </span>
                <span className={`flex-shrink-0 ml-4 transition-transform duration-300 ${isOpen ? 'transform rotate-180' : ''}`} aria-hidden="true">
                  <svg className="w-6 h-6 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                </span>
            </button>
            <div 
                id={panelId}
                role="region"
                aria-labelledby={buttonId}
                className={`grid transition-all duration-300 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
            >
                <div className="overflow-hidden">
                    <p className="text-ink-2 pb-6 pl-10 pr-12">{item.answer}</p>
                </div>
            </div>
        </div>
    );
};


export const FaqSection: React.FC = () => {
    const [openIndex, setOpenIndex] = useState<number | null>(0);

    const handleToggle = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    return (
        <section id="faq" className="py-24 md:py-20 sm:py-12 scroll-mt-20 reveal">
            <div className="container mx-auto px-6 max-w-3xl">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold section-title">
                        Perguntas Frequentes
                    </h2>
                </div>
                <div className="space-y-6">
                    {faqData.map((item, index) => (
                        <FaqAccordionItem 
                            key={index} 
                            item={item}
                            isOpen={openIndex === index}
                            onClick={() => handleToggle(index)}
                            index={index}
                        />
                    ))}
                </div>
            </div>
        </section>
    );
};
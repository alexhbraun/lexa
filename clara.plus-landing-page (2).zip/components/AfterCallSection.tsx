import React from 'react';

export const AfterCallSection: React.FC = () => {
    return (
        <section id="after-call" className="py-24 md:py-20 sm:py-12 scroll-mt-20 reveal">
            <div className="container mx-auto px-6">
                <div className="bg-white/3 backdrop-blur-lg border border-border rounded-2xl p-8 md:p-12">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                        <div>
                            <p className="text-sm font-bold tracking-wider uppercase text-coral mb-3">Follow-up automático</p>
                            <h2 className="text-3xl md:text-4xl font-bold text-ink-1">
                                Depois da ligação, a Clara continua trabalhando
                            </h2>
                            <p className="mt-4 text-lg text-ink-2 max-w-lg">
                                Ao final de cada chamada, a Clara gera um resumo do que foi dito, envia à equipe por WhatsApp e registra tudo no histórico. Nenhum detalhe se perde.
                            </p>
                        </div>
                        <div className="relative">
                            <div className="absolute top-4 right-4 bg-coral/20 text-coral text-xs font-bold px-3 py-1 rounded-full flex items-center gap-2">
                                <span className="relative flex h-2 w-2">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-coral opacity-75"></span>
                                    <span className="relative inline-flex rounded-full h-2 w-2 bg-coral"></span>
                                </span>
                                Automação ativa
                            </div>
                            <div className="card-gradient-border from-coral to-violet-acc p-px rounded-2xl shadow-[0_0_26px_rgba(255,110,91,0.15)]">
                                <div className="bg-card rounded-[15px] p-8">
                                    <div className="space-y-4">
                                        <div className="flex items-start gap-4">
                                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-500/20 flex items-center justify-center mt-1">
                                                <span className="text-xl">📞</span>
                                            </div>
                                            <div className="text-ink-1 bg-bg-1 border border-border p-4 rounded-lg flex-1">
                                                <p className="font-bold text-slate-300 text-sm">Nova Notificação da Clara:</p>
                                                <p className="mt-1">"Maria Souza ligou (11 98765-4321) avisando que chegará 10 minutos atrasada para a consulta das 15h."</p>
                                            </div>
                                        </div>
                                        <div className="flex items-start gap-4 justify-end">
                                            <div className="text-ink-1 bg-coral/10 border border-coral/30 p-4 rounded-lg max-w-sm text-right">
                                                <p className="font-bold text-coral text-sm">Ação Automática:</p>
                                                <p className="mt-1">Resumo da chamada enviado para o WhatsApp da Recepção.</p>
                                            </div>
                                            <div className="flex-shrink-0 h-10 w-10 rounded-full bg-coral/20 flex items-center justify-center mt-1">
                                                <span className="text-xl">📲</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};
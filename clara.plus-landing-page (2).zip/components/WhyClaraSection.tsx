import React from 'react';
import { 
    IconAtendimento24h, 
    IconAgendaAutomatica, 
    IconLembretesVoz, 
    IconEnviaDocumentos, 
    IconResumosAutomaticos, 
    IconTransferenciaHumana 
} from './Icons';

interface BenefitCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const BenefitCard: React.FC<BenefitCardProps> = ({ icon, title, description }) => (
  <div className="card-gradient-border p-px rounded-2xl h-full transition-all duration-300 ease-out hover:-translate-y-1.5 hover:shadow-[0_0_30px_rgba(160,111,255,0.2)] reveal">
    <div className="bg-white/5 backdrop-blur-lg h-full p-6 md:p-8 rounded-[15px] flex flex-col items-center text-center">
      <div className="text-coral mb-5 drop-shadow-[0_2px_8px_rgba(255,110,91,0.5)]">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-ink-1 mb-2">{title}</h3>
      <p className="text-ink-2 text-base leading-relaxed flex-grow">{description}</p>
    </div>
  </div>
);

export const WhyClaraSection: React.FC = () => {
    const benefits = [
        {
            icon: <IconAtendimento24h className="h-12 w-12" />,
            title: "Atendimento 24h com voz natural",
            description: "A Clara atende 100% das ligações — inclusive fora do horário comercial — com empatia e tom humano, garantindo que nenhum paciente fique sem resposta."
        },
        {
            icon: <IconAgendaAutomatica className="h-12 w-12" />,
            title: "Agenda e confirma automaticamente",
            description: "Integrada ao calendário da clínica, a Clara agenda e confirma consultas com precisão, sem erros ou sobreposição de horários."
        },
        {
            icon: <IconLembretesVoz className="h-12 w-12" />,
            title: "Lembretes por WhatsApp ou ligação de voz",
            description: "A clínica escolhe o canal: lembretes automáticos por WhatsApp ou ligação reduzem faltas em até 30%."
        },
        {
            icon: <IconEnviaDocumentos className="h-12 w-12" />,
            title: "Envia documentos durante a conversa",
            description: "Durante o atendimento, a Clara envia formulários, guias ou instruções diretamente por WhatsApp — sem interromper a conversa."
        },
        {
            icon: <IconResumosAutomaticos className="h-12 w-12" />,
            title: "Resumos automáticos para a equipe",
            description: "Ao final de cada atendimento, a Clara gera um resumo completo e envia à equipe — nenhum detalhe importante se perde."
        },
        {
            icon: <IconTransferenciaHumana className="h-12 w-12" />,
            title: "Transfere para humano quando necessário",
            description: "Quando identifica que o paciente precisa de atenção específica, a Clara transfere a chamada para a recepção, com todo o contexto da conversa."
        }
    ];

    return (
        <section id="why-clara" className="py-24 md:py-20 sm:py-12 scroll-mt-20 bg-[#18112D]">
            <div className="container mx-auto px-6">
                <div className="text-center max-w-3xl mx-auto reveal">
                    <h2 className="text-3xl md:text-4xl font-bold section-title">
                        Por que clínicas escolhem a Clara
                    </h2>
                    <p className="mt-4 text-lg text-ink-2">O que torna a Clara diferente.</p>
                </div>
                <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {benefits.map((benefit, index) => (
                        <BenefitCard key={index} {...benefit} />
                    ))}
                </div>
            </div>
        </section>
    );
};

import React from 'react';
import { CalendarIcon } from './Icons';

interface PricingSectionProps {
  onNavigateToPrep: () => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onNavigateToPrep }) => {
  return (
    <>
      <section id="pricing" className="py-24 md:py-20 sm:py-12 scroll-mt-20 reveal">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold section-title">
              Comece a transformar sua clínica hoje.
            </h2>
            <p className="mt-4 text-lg text-ink-2">
              Escolha o plano ideal ou experimente a Clara sem compromisso.
            </p>
          </div>
          
          <div className="mt-16 max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-12 items-stretch">
              {/* Free Trial */}
              <div className="bg-gradient-to-br from-coral to-violet-acc rounded-2xl p-8 text-center flex flex-col shadow-[0_8px_38px_rgba(255,110,91,0.25)] transition-transform duration-300 hover:-translate-y-1">
                  <h3 className="text-2xl font-bold text-ink-1">Teste Gratuito</h3>
                  <p className="text-ink-1/80 text-sm mt-1">Sem cartão de crédito.</p>
                  <div className="my-6 flex-grow flex items-center justify-center">
                      <p className="text-lg text-ink-1">
                          Experimente a versão completa com até <span className="font-bold">100 minutos</span> de uso, sem custo e sem compromisso.
                      </p>
                  </div>
                  <button
                      onClick={onNavigateToPrep}
                      className="w-full inline-flex items-center justify-center gap-2 bg-white text-coral font-bold text-lg px-8 py-3 rounded-full hover:bg-opacity-90 transition-all duration-300 ease-in-out transform hover:scale-105"
                  >
                      <CalendarIcon />
                      Ativar teste gratuito 🚀
                  </button>
              </div>

              {/* Starter Plan */}
              <div className="bg-bg-2 border border-coral/30 rounded-2xl p-8 text-center flex flex-col relative transition-transform duration-300 hover:-translate-y-1">
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-coral text-white text-xs font-bold px-4 py-1 rounded-full">MAIS ESCOLHIDO</div>
                  <h3 className="text-2xl font-bold text-ink-1">Clara Starter</h3>
                  <p className="text-coral/80 text-sm mt-1">Ideal para clínicas pequenas</p>
                  <div className="my-4">
                    <p className="text-5xl font-extrabold text-coral font-sans">
                        R$ 300<span className="text-lg font-medium text-ink-2">/mês</span>
                    </p>
                    <p className="text-sm font-medium text-ink-2 -mt-1">+ R$ 1/minuto</p>
                  </div>
                  <ul className="text-ink-2 text-left space-y-3 px-4 flex-grow">
                      <li className="flex items-center gap-3"><span className="text-coral">✓</span> Atendimento por voz</li>
                      <li className="flex items-center gap-3"><span className="text-coral">✓</span> Agendamento automático</li>
                      <li className="flex items-center gap-3"><span className="text-coral">✓</span> Resumos de chamada</li>
                      <li className="flex items-center gap-3"><span className="text-coral">✓</span> Notificações internas</li>
                  </ul>
                  <button
                      onClick={onNavigateToPrep}
                      className="mt-8 w-full inline-flex items-center justify-center gap-2 bg-gradient-to-r from-coral to-coral-2 text-white font-bold text-lg px-8 py-3 rounded-full hover:brightness-110 transition-all duration-300 ease-in-out"
                  >
                      Assine o Starter
                  </button>
              </div>
          </div>
        </div>
      </section>
    </>
  );
};

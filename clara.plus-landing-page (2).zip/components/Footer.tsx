import React from 'react';

const Logo: React.FC = () => (
    <div className="flex items-center justify-center space-x-2">
      <img src="https://ik.imagekit.io/rgqefde41/Logo%20Clara%20sem%20fundo.png?updatedAt=1761990691836" alt="Clara.plus Logo" className="h-16 w-auto" />
    </div>
);


export const Footer: React.FC = () => {
  return (
    <footer id="footer" className="bg-brand-dark-start relative">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-coral to-transparent opacity-30"></div>
      <div className="container mx-auto px-6 py-12">
          <div className="flex flex-col items-center text-center space-y-6">
              <div>
                <Logo />
                <p className="text-sm text-text-muted-light mt-3 max-w-xs">Clara cuida das ligações — e de quem mais importa: seus pacientes.</p>
              </div>
              <div className="flex space-x-6 text-text-links">
                  <a href="#" className="hover:text-coral transition-colors">Termos</a>
                  <a href="#" className="hover:text-coral transition-colors">Privacidade (LGPD)</a>
                  <a href="#" className="hover:text-coral transition-colors">Contato</a>
              </div>
          </div>
          <div className="text-center text-slate-500 text-sm mt-10 pt-8 border-t border-white/10">
            <p>&copy; 2025 Clara.plus. Todos os direitos reservados.</p>
          </div>
      </div>
    </footer>
  );
};
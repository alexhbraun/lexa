
import React, { useState, Suspense, lazy } from 'react';
import { Modal } from './Modal';
import { VoiceIcon, CalendarIcon } from './Icons';

const AudioDemoContent = lazy(() => import('./AudioDemoContent'));

interface HeroSectionProps {
  onNavigateToPrep: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onNavigateToPrep }) => {
  const [isAudioModalOpen, setIsAudioModalOpen] = useState(false);

  const handleBookFromAudioDemo = () => {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({ event: 'demo_to_booking' });
    setIsAudioModalOpen(false);
    setTimeout(() => {
        onNavigateToPrep();
    }, 200); 
  };

  return (
    <>
      <section className="relative overflow-hidden pt-20 md:pt-24 pb-20 md:pb-24 reveal">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_center,rgba(155,81,224,0.15),transparent_70%)]"></div>
        
        {/* Sound Wave Graphic */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-48 -z-10 flex items-center justify-center opacity-25 [mask-image:radial-gradient(ellipse_at_center,white_30%,transparent_80%)]">
            <div className="flex items-center justify-center gap-1.5 w-full h-full">
                {Array.from({ length: 60 }).map((_, i) => {
                    const half = 30;
                    const distanceFromCenter = Math.abs(i - half);
                    const delay = distanceFromCenter * 30 + Math.random() * 100;
                    const duration = 1.2 + Math.random();
                    const baseHeight = (1 - (distanceFromCenter / half));
                    const heightPercentage = (baseHeight * 70) + 10 + (Math.random() * 10 - 5);

                    return (
                        <div
                            key={i}
                            className="w-1 bg-white rounded-full animate-sound-wave"
                            style={{
                                height: `${Math.max(5, heightPercentage)}%`,
                                animationDelay: `${delay}ms`,
                                animationDuration: `${duration.toFixed(2)}s`,
                            }}
                        />
                    );
                })}
            </div>
        </div>

        <div className="container mx-auto px-6 pt-8 text-center">
          <h1 className="leading-tight animate-text-focus-in hero-title">
            Sua clínica com atendimento 24h, sem perder a empatia.
          </h1>
          <p className="mt-6 max-w-[700px] mx-auto text-lg md:text-xl text-ink-2">
            A Clara atende suas ligações com voz natural, agenda consultas e confirma horários por WhatsApp — tudo sozinha, 24h por dia.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-4">
            <button
              onClick={onNavigateToPrep}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-gradient-to-br from-coral to-coral-2 text-white font-semibold text-lg px-8 py-3 rounded-full transition-all duration-300 ease-in-out hover:brightness-110 animate-cta-pulse"
            >
              <CalendarIcon className="h-5 w-5" />
              Reserve um horário
            </button>
            <div className="flex flex-col items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => setIsAudioModalOpen(true)}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-transparent border border-white/25 text-white font-semibold text-lg px-8 py-3 rounded-full hover:bg-white/[.07] transition-all duration-300 ease-in-out hover:-translate-y-0.5"
              >
                <VoiceIcon className="h-5 w-5" />
                Fale com a Clara agora →
              </button>
              <p className="text-sm text-ink-2/60 font-medium">
                Tire dúvidas rápidas antes de agendar.
              </p>
            </div>
          </div>
        </div>
      </section>

      <Modal 
        isOpen={isAudioModalOpen} 
        onClose={() => setIsAudioModalOpen(false)} 
        maxWidthClass="max-w-md"
        titleId="hero-audio-title"
        descriptionId="hero-audio-desc"
      >
        <Suspense fallback={<div className="h-[244px]" />}>
            {isAudioModalOpen && <AudioDemoContent onBookDemo={handleBookFromAudioDemo} titleId="hero-audio-title" descriptionId="hero-audio-desc" />}
        </Suspense>
      </Modal>
    </>
  );
};

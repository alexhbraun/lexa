import React from 'react';
import { Testimonial } from '../types';

const testimonialData: Testimonial[] = [
  {
    quote: "A Clara atendeu 48 ligações no fim de semana e garantiu 7 novos pacientes. Incrível.",
    name: "Dra. Fernanda",
    title: "Odontologia Integrada"
  },
  {
    quote: "Antes perdíamos consultas por falta de confirmação. Agora a Clara faz tudo.",
    name: "Clínica Vitta",
    title: "São Paulo"
  }
];

const QuoteIcon = () => (
    <svg className="absolute top-0 left-0 h-24 w-24 text-white/5 transform -translate-x-4 -translate-y-6" stroke="currentColor" fill="none" viewBox="0 0 144 144"><path strokeWidth="2" d="M41.48 130.41C19.24 130.41 0 110.65 0 87.82 0 66.71 18.27 49.31 40.13 49.31c2.16 0 4.14.2 5.9.58V0h44.18v88.74C90.21 111.57 68.45 130.41 41.48 130.41zm82.02 0c-22.24 0-41.48-19.76-41.48-42.59 0-21.11 18.27-38.51 40.13-38.51 2.16 0 4.14.2 5.9.58V0h44.18v88.74C172.23 111.57 150.47 130.41 123.5 130.41z"></path></svg>
)

const HighlightedQuote: React.FC<{ text: string; highlight: string }> = ({ text, highlight }) => {
    if (!text.includes(highlight)) return <>{`“${text}”`}</>;
    const parts = text.split(highlight);
    return (
        <>
            “{parts[0]}
            <span className="inline-block bg-coral/10 text-coral font-semibold px-2 py-0.5 rounded-md mx-1">{highlight}</span>
            {parts[1]}”
        </>
    );
};

const TestimonialCard: React.FC<{ testimonial: Testimonial }> = ({ testimonial }) => {
  const initials = testimonial.name.split(' ').map(n => n[0]).join('');

  return (
    <div className="bg-white/5 backdrop-blur-md p-8 rounded-2xl border border-border relative overflow-hidden flex flex-col h-full transition-all duration-300 hover:border-coral/30 hover:-translate-y-1">
      <QuoteIcon />
      <p className="text-ink-2 italic relative z-10 text-lg flex-grow">
        {testimonial.name === "Dra. Fernanda" 
          ? <HighlightedQuote text={testimonial.quote} highlight="7 novos pacientes" />
          : `“${testimonial.quote}”`
        }
      </p>
      <div className="mt-6 pt-6 border-t border-border flex items-center">
        <div className="h-12 w-12 rounded-full bg-violet-acc/10 flex-shrink-0 mr-4 p-2 flex items-center justify-center font-bold text-violet-acc">
          {initials}
        </div>
        <div>
          <p className="font-bold text-ink-1">{testimonial.name}</p>
          <p className="text-sm text-coral font-medium">{testimonial.title}</p>
        </div>
      </div>
    </div>
  );
};

export const TestimonialsSection: React.FC = () => {
  return (
    <section id="testimonials" className="py-24 md:py-20 sm:py-12 scroll-mt-20 reveal">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold section-title">
            Histórias reais de quem já usa a Clara
          </h2>
        </div>
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {testimonialData.map((testimonial, index) => (
            <TestimonialCard key={index} testimonial={testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};
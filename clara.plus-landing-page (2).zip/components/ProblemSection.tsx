
import React, { useState, Suspense, lazy } from 'react';
import { Modal } from './Modal';
import { HeadphonesIcon, UserLostIcon, VoiceCalendarIcon, BellRingIcon } from './Icons';

const AudioDemoContent = lazy(() => import('./AudioDemoContent'));

const PainPoint: React.FC<{ icon: React.ReactNode; title: string; text: React.ReactNode; tooltipText?: string }> = ({ icon, title, text, tooltipText }) => (
  <div className="group relative card-gradient-border from-coral to-violet-acc p-px rounded-2xl h-full transition-transform duration-300 ease-out hover:-translate-y-1">
    <div className="bg-card h-full p-8 rounded-[15px] text-center shadow-[inset_0_0_18px_rgba(255,110,91,0.05)]">
      <div className="h-16 w-16 mx-auto mb-5 text-coral bg-white/5 rounded-full p-3">{icon}</div>
      <h3 className="font-semibold text-xl text-ink-1 tracking-wide">{title}</h3>
      <p className="text-ink-2 mt-2">{text}</p>
    </div>
    {tooltipText && (
      <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-max max-w-[90%] px-3 py-1.5 bg-bg-1 border border-border text-ink-2 text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-10 text-center shadow-lg">
        {tooltipText}
      </div>
    )}
  </div>
);

interface ProblemSectionProps {
  onNavigateToPrep: () => void;
}

export const ProblemSection: React.FC<ProblemSectionProps> = ({ onNavigateToPrep }) => {
  const [isAudioModalOpen, setIsAudioModalOpen] = useState(false);

  const handleBookFromAudioDemo = () => {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({ event: 'demo_to_booking' });
    setIsAudioModalOpen(false);
    setTimeout(() => {
        onNavigateToPrep();
    }, 200); 
  };

  return (
    <>
      <section id="problem" className="py-24 md:py-20 sm:py-12 scroll-mt-20 reveal">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold section-title">
              A recepção da sua clínica vive sobrecarregada?
            </h2>
            <p className="mt-4 text-lg text-ink-2">
              Telefone tocando, pacientes na espera, e a agenda um caos. Se essa é sua realidade, o custo é alto: pacientes frustrados e receita perdida.
            </p>
          </div>
          <div className="mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <PainPoint icon={<UserLostIcon />} title="Nunca mais perca um paciente" text="Clara atende 100% das ligações, 24h por dia — até fora do expediente." />
            <PainPoint icon={<VoiceCalendarIcon />} title="Agenda inteligente e automática" text="Integrada ao seu calendário, Clara agenda e confirma em segundos, sem esforço humano." />
            <PainPoint 
              icon={<BellRingIcon />} 
              title="Reduza faltas com lembretes inteligentes" 
              text={
                <>
                  A Clara envia lembretes automáticos <strong className="text-ink-1">por WhatsApp ou ligação de voz</strong>, conforme a preferência da sua clínica — reduzindo no-show em até 30%.
                </>
              }
              tooltipText="Lembretes por voz são ideais para pacientes idosos ou consultas importantes."
            />
          </div>
          <div className="mt-16 text-center">
              <p className="text-xl md:text-2xl font-medium text-ink-1">
                  Libere sua equipe do telefone. Deixe a Clara cuidar das chamadas.
              </p>
          </div>
          <div className="mt-8 text-center">
              <button
                onClick={() => setIsAudioModalOpen(true)}
                className="inline-flex items-center justify-center gap-2 bg-transparent border-2 border-white/20 font-bold text-lg px-8 py-4 rounded-full hover:bg-white/10 transition-all duration-300 ease-in-out hover:-translate-y-0.5"
              >
                <HeadphonesIcon />
                Ouça uma ligação real da Clara
              </button>
          </div>
        </div>
      </section>

      <Modal 
        isOpen={isAudioModalOpen} 
        onClose={() => setIsAudioModalOpen(false)} 
        maxWidthClass="max-w-md"
        titleId="problem-audio-title"
        descriptionId="problem-audio-desc"
      >
        <Suspense fallback={<div className="h-[244px]" />}>
            {isAudioModalOpen && <AudioDemoContent onBookDemo={handleBookFromAudioDemo} titleId="problem-audio-title" descriptionId="problem-audio-desc" />}
        </Suspense>
      </Modal>
    </>
  );
};


import React, { useState, Suspense, lazy } from 'react';
import { Modal } from './Modal';
import { PlayIcon, CalendarIcon } from './Icons';

const AudioDemoContent = lazy(() => import('./AudioDemoContent'));

interface FinalCtaSectionProps {
  onNavigateToPrep: () => void;
}

export const FinalCtaSection: React.FC<FinalCtaSectionProps> = ({ onNavigateToPrep }) => {
  const [isAudioModalOpen, setIsAudioModalOpen] = useState(false);

   const handleBookFromAudioDemo = () => {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({ event: 'demo_to_booking' });
    setIsAudioModalOpen(false);
    setTimeout(() => {
        onNavigateToPrep();
    }, 200); 
  };

  return (
    <>
      <section id="cta" className="py-24 relative reveal">
        <div className="absolute inset-0 -z-10 flex items-center justify-center">
            <div className="w-full max-w-lg h-64 bg-[radial-gradient(ellipse_at_center,rgba(255,110,91,0.18),transparent_80%)]"></div>
        </div>
        <div className="container mx-auto px-6 text-center relative z-10">
          <h2 className="text-3xl md:text-5xl font-extrabold max-w-3xl mx-auto section-title">
            Deixe a Clara cuidar das ligações — e foque no que você faz de melhor: cuidar de pessoas.
          </h2>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onNavigateToPrep}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-gradient-to-br from-coral to-coral-2 text-white font-semibold text-lg px-8 py-3 rounded-full transition-all duration-300 ease-in-out hover:brightness-110 animate-cta-pulse"
            >
              <CalendarIcon className="h-5 w-5" />
              Reserve um horário
            </button>
            <button
              onClick={() => setIsAudioModalOpen(true)}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-transparent border border-white/25 text-white font-semibold text-lg px-8 py-3 rounded-full hover:bg-white/[.07] transition-all duration-300 ease-in-out hover:-translate-y-0.5"
            >
              <PlayIcon className="h-5 w-5" />
              Ouça uma demonstração
            </button>
          </div>
           <p className="mt-6 text-sm text-ink-2/80">Agende agora e veja a Clara em ação na sua clínica.</p>
        </div>
      </section>

      <Modal 
        isOpen={isAudioModalOpen} 
        onClose={() => setIsAudioModalOpen(false)} 
        maxWidthClass="max-w-md"
        titleId="cta-audio-title"
        descriptionId="cta-audio-desc"
      >
          <Suspense fallback={<div className="h-[244px]" />}>
            {isAudioModalOpen && <AudioDemoContent onBookDemo={handleBookFromAudioDemo} titleId="cta-audio-title" descriptionId="cta-audio-desc" />}
        </Suspense>
      </Modal>
    </>
  );
};

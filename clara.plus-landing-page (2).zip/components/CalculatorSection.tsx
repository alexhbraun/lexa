import React, { useState, useMemo, useEffect, useRef } from 'react';

const CalculatorSlider: React.FC<{
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
  unit?: string;
  suffix?: string;
}> = ({ label, value, min, max, step, onChange, unit = '', suffix = '' }) => (
    <div className="space-y-3">
        <label className="flex justify-between items-center text-ink-2">
            <span>{label}</span>
            <span className="font-bold text-ink-1 text-lg">{`${unit}${value}${suffix}`}</span>
        </label>
        <input
            type="range"
            min={min}
            max={max}
            step={step}
            value={value}
            onChange={(e) => onChange(parseFloat(e.target.value))}
            className="w-full h-2 bg-transparent rounded-lg appearance-none cursor-pointer"
        />
    </div>
);

export const CalculatorSection = () => {
    const [missedCalls, setMissedCalls] = useState(10);
    const [consultationValue, setConsultationValue] = useState(200);
    const [bookingRate, setBookingRate] = useState(15);
    const [displayRevenue, setDisplayRevenue] = useState(0);

    const prevRevenueRef = useRef(0);
    const animationFrameRef = useRef<number>();

    const { monthlyRevenue, extraConsultations } = useMemo(() => {
        const workingDays = 22;
        const extraConsultationsPerDay = missedCalls * (bookingRate / 100);
        const extraConsultationsPerMonth = Math.round(extraConsultationsPerDay * workingDays);
        const additionalMonthlyRevenue = extraConsultationsPerMonth * consultationValue;

        return {
            monthlyRevenue: additionalMonthlyRevenue,
            extraConsultations: extraConsultationsPerMonth,
        };
    }, [missedCalls, consultationValue, bookingRate]);
    
    useEffect(() => {
        const start = prevRevenueRef.current;
        const end = monthlyRevenue;
        if (start === end) return;

        const duration = 1200;
        let startTime: number | null = null;
        
        const animate = (timestamp: number) => {
            if (!startTime) startTime = timestamp;
            const progress = Math.min((timestamp - startTime) / duration, 1);
            const current = Math.floor(start + progress * (end - start));
            setDisplayRevenue(current);
            
            if (progress < 1) {
                animationFrameRef.current = requestAnimationFrame(animate);
            } else {
                prevRevenueRef.current = end;
            }
        };
        
        if (animationFrameRef.current) {
            cancelAnimationFrame(animationFrameRef.current);
        }
        animationFrameRef.current = requestAnimationFrame(animate);

        return () => {
            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
            }
        };
    }, [monthlyRevenue]);

    return (
        <section id="calculator" className="py-24 md:py-20 sm:py-12 scroll-mt-20 reveal">
            <div className="container mx-auto px-6">
                <div className="text-center max-w-3xl mx-auto">
                    <h2 className="text-3xl md:text-4xl font-bold section-title">
                        Quanto sua clínica pode crescer com a Clara?
                    </h2>
                    <p className="mt-4 text-lg text-ink-2">
                        Use nossa calculadora e descubra o potencial de crescimento que a Clara pode destravar para sua clínica. O resultado pode surpreender.
                    </p>
                </div>

                <div className="mt-16 max-w-5xl mx-auto bg-bg-1 border border-border rounded-2xl shadow-lg overflow-hidden grid grid-cols-1 lg:grid-cols-2">
                    
                    <div className="p-8 md:p-12 space-y-8">
                        <h3 className="text-2xl font-bold text-ink-1">Ajuste os valores</h3>
                        <CalculatorSlider
                            label="Ligações perdidas por dia"
                            value={missedCalls}
                            min={1}
                            max={50}
                            step={1}
                            onChange={setMissedCalls}
                        />
                        <CalculatorSlider
                            label="Valor médio da consulta"
                            value={consultationValue}
                            min={50}
                            max={1000}
                            step={10}
                            onChange={setConsultationValue}
                            unit="R$ "
                        />
                        <CalculatorSlider
                            label="Taxa de agendamento"
                            value={bookingRate}
                            min={10}
                            max={100}
                            step={5}
                            onChange={setBookingRate}
                            suffix="%"
                        />
                    </div>
                    
                    <div className="bg-white/5 p-8 md:p-12 flex flex-col justify-center items-center text-center shadow-[0_0_60px_rgba(255,110,91,0.25)]">
                        <h3 className="text-xl font-bold text-ink-1">Potencial de receita mensal recuperada:</h3>
                        <div className="my-4">
                            <p className="text-5xl md:text-6xl font-extrabold text-coral font-sans" style={{textShadow: '0 0 15px rgba(255, 110, 91, 0.4)'}}>
                                {displayRevenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                            </p>
                            <p className="text-ink-2 mt-1">em faturamento adicional todo mês</p>
                        </div>
                        <div className="mt-4 text-lg text-ink-1 font-medium bg-white/10 px-6 py-3 rounded-full">
                           <span className="font-bold">{extraConsultations}</span> consultas a mais por mês
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};
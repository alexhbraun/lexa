
import React, { useEffect, useState } from 'react';
import { HeroSection } from './components/HeroSection';
import { ProblemSection } from './components/ProblemSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { PricingSection } from './components/PricingSection';
import { FaqSection } from './components/FaqSection';
import { FinalCtaSection } from './components/FinalCtaSection';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CalculatorSection } from './components/CalculatorSection';
import { WhatClaraDoesSection } from './components/WhatClaraDoesSection';
import { WhyClaraSection } from './components/WhyClaraSection';
import { PrepPage } from './components/PrepPage';

function App() {
  const [view, setView] = useState<'landing' | 'prep'>('landing');

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('in-view');
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

    const elements = document.querySelectorAll('.reveal');
    elements.forEach(el => observer.observe(el));

    return () => {
        elements.forEach(el => observer.unobserve(el));
    };
  }, [view]);

  const handleNavigateToPrep = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setView('prep');
  };

  const handleBackToLanding = () => {
    setView('landing');
  };

  if (view === 'prep') {
    return (
      <div className="bg-gradient-to-b from-bg-1 to-[#1C1234] text-ink-2 font-sans antialiased relative min-h-screen text-[17px] leading-[1.6]">
        <Header onLogoClick={handleBackToLanding} />
        <main>
          <PrepPage />
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-b from-bg-1 to-[#1C1234] text-ink-2 font-sans antialiased relative overflow-x-hidden bg-[length:200%_200%] animate-slow-pan text-[17px] leading-[1.6]">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1200px] h-[800px] bg-[radial-gradient(circle_at_50%_16%,rgba(255,110,91,0.15),transparent_55%)] -z-10 opacity-70"></div>
      <div className="relative z-10">
        <Header />
        <main>
          <HeroSection onNavigateToPrep={handleNavigateToPrep} />
          <div className="bg-bg-1"><ProblemSection onNavigateToPrep={handleNavigateToPrep} /></div>
          <WhatClaraDoesSection onNavigateToPrep={handleNavigateToPrep} />
          <div className="bg-bg-2"><CalculatorSection /></div>
          <WhyClaraSection />
          <div className="bg-bg-2"><TestimonialsSection /></div>
          <div className="bg-bg-1"><PricingSection onNavigateToPrep={handleNavigateToPrep} /></div>
          <div className="bg-bg-2"><FaqSection /></div>
          <div className="bg-bg-1"><FinalCtaSection onNavigateToPrep={handleNavigateToPrep} /></div>
        </main>
        <Footer />
      </div>
    </div>
  );
}

export default App;
